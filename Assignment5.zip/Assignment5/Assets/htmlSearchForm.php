<?php
/**
 * Created by PhpStorm.
 * User: 001338244
 * Date: 11/27/2017
 * Time: 12:21 PM
 */
?>

<input type="submit" name="submit" value="Submit" />