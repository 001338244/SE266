<?php
/**
 * Created by PhpStorm.
 * User: 001338244
 * Date: 11/8/2017
 * Time: 1:23 PM
 */
?>

<form method="post" action="#">
    Site Name: <input type="text" name="site" /><br />
    <!--HTML Link: <input type="text" name="link" /><br />-->
    <input type="submit" name="submit" value="Submit" />
</form>