<?php
/**
 * Created by PhpStorm.
 * User: 001338244
 * Date: 11/8/2017
 * Time: 1:20 PM
 */


//Lets make a way to get the URL input
include_once ("assets/header.html");
include_once ("assets/dbconn.php");
require_once ("assets/functionsToGetStuffDone.php");
include_once ("assets/htmlSearchForm.php");


$action = filter_input(INPUT_POST, 'action', FILTER_SANITIZE_STRING) ?? "";



$db = dbconn();



siteDropDown($db);


$select = filter_input(INPUT_POST, 'option', FILTER_SANITIZE_STRING) ?? "";





grabSites ($db, $select);

//switch ( $action ) {
    //case "Submit":



       // break;
//}

