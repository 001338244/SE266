<?php
/**
 * Created by PhpStorm.
 * User: calexander
 * Date: 10/29/17
 * Time: 5:10 PM
 */
?>
<footer>Copyright &copy; <?php echo date('Y'); ?>, Clark Alexander. All Rights Reserved</footer>
</body>
</html>
